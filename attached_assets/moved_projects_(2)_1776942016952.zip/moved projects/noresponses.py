#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
/home/noresponses.py

نسخهٔ چندکاربره: گزارش برای چند chat_id (جداشده با کاما) ارسال می‌شود.
مثلاً در /home/.env بنویس:

TELEGRAM_TOKEN_NORESP=123456789:ABCDEF...
CHAT_ID_NORESP=111111111,222222222,333333333
"""

import os
import time
import logging
from dotenv import load_dotenv
import requests
import dns.resolver

# ---------- تنظیمات ----------
DOMAINS_FILE = "/home/domains.txt"
LOG_FILE = "/home/noresponses.log"
ENV_FILE = "/home/.env"

RESOLVERS = ["8.8.8.8", "8.8.4.4", "1.1.1.1"]
DNS_TIMEOUT = 9.0
SLEEP_BETWEEN = 0.1
TELEGRAM_TIMEOUT = 15
TELEGRAM_RETRIES = 3

# ---------- لاگ ----------
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s: %(message)s",
)

# ---------- env ----------
load_dotenv(ENV_FILE)
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN_NORESP")
CHAT_IDS_RAW = os.getenv("CHAT_ID_NORESP", "")
CHAT_IDS = [x.strip() for x in CHAT_IDS_RAW.split(",") if x.strip()]

# ---------- توابع ----------
def send_telegram_message(text):
    """ارسال پیام به چند chat_id با retry"""
    if not TELEGRAM_TOKEN or not CHAT_IDS:
        logging.error("TELEGRAM_TOKEN_NORESP یا CHAT_ID_NORESP تنظیم نشده‌اند (%s)", ENV_FILE)
        print("[!] تنظیمات تلگرام در .env ناقص است.")
        return False

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    chunks = [text[i:i+3500] for i in range(0, len(text), 3500)]
    ok_any = False

    for chat_id in CHAT_IDS:
        for idx, chunk in enumerate(chunks, start=1):
            data = {"chat_id": chat_id, "text": chunk, "parse_mode": "HTML", "disable_web_page_preview": True}
            for attempt in range(1, TELEGRAM_RETRIES + 1):
                try:
                    r = requests.post(url, data=data, timeout=TELEGRAM_TIMEOUT)
                    jr = r.json()
                    logging.info("Telegram to %s attempt %d/%d chunk %d status=%s ok=%s",
                                 chat_id, attempt, TELEGRAM_RETRIES, idx, r.status_code, jr.get("ok"))
                    if r.status_code == 200 and jr.get("ok"):
                        ok_any = True
                        break
                except requests.exceptions.ReadTimeout as e:
                    logging.warning("Telegram timeout to %s attempt %d: %s", chat_id, attempt, e)
                except Exception as e:
                    logging.exception("Telegram exception to %s attempt %d: %s", chat_id, attempt, e)
                if attempt < TELEGRAM_RETRIES:
                    time.sleep(1)
    return ok_any

def resolve_with(resolver_ip, domain):
    resolver = dns.resolver.Resolver(configure=False)
    resolver.nameservers = [resolver_ip]
    resolver.lifetime = DNS_TIMEOUT
    resolver.timeout = DNS_TIMEOUT
    try:
        answers = resolver.resolve(domain, "A")
        ips = [rdata.to_text() for rdata in answers]
        return True, ips
    except dns.resolver.NoAnswer:
        try:
            answers6 = resolver.resolve(domain, "AAAA")
            ips6 = [rdata.to_text() for rdata in answers6]
            return True, ips6
        except Exception as e6:
            return False, f"NoAnswer/No AAAA: {e6}"
    except dns.resolver.NXDOMAIN:
        return False, "NXDOMAIN"
    except dns.resolver.Timeout:
        return False, "Timeout"
    except dns.resolver.NoNameservers:
        return False, "NoNameservers"
    except Exception as e:
        return False, f"OtherError: {e}"

def check_domain(domain):
    d = domain.strip()
    if not d:
        return None
    if d.startswith("http://") or d.startswith("https://"):
        d = d.split("://", 1)[1].split("/", 1)[0]

    results = []
    any_ok = False
    for r_ip in RESOLVERS:
        ok, data = resolve_with(r_ip, d)
        results.append((r_ip, ok, data))
        if ok:
            any_ok = True
    return {"domain": d, "results": results, "any_ok": any_ok}

# ---------- برنامه اصلی ----------
def main():
    print("=== noresponses.py (multi-chat) starting ===")
    logging.info("==== job started ====")

    if not os.path.exists(DOMAINS_FILE):
        msg = f"File not found: {DOMAINS_FILE}"
        print("[!] " + msg)
        logging.error(msg)
        return

    with open(DOMAINS_FILE, "r") as f:
        domains = [line.strip() for line in f if line.strip()]

    not_resolved = []

    for domain in domains:
        print(f"[·] Checking {domain} ...")
        try:
            r = check_domain(domain)
            for resolver_ip, ok, data in r["results"]:
                if ok:
                    print(f"  ✅ {resolver_ip} -> {data}")
                else:
                    print(f"  ❌ {resolver_ip} -> {data}")
            if not r["any_ok"]:
                not_resolved.append(r)
            time.sleep(SLEEP_BETWEEN)
        except Exception as e:
            logging.exception("Exception while checking %s: %s", domain, e)
            print(f"[!] Exception while checking {domain}: {e}")

    if not not_resolved:
        print("All domains resolvable via specified DNS servers.")
        logging.info("All domains resolvable. No report sent.")
        print("=== done ===")
        return

    lines = []
    for r in not_resolved:
        d = r["domain"]
        res_parts = []
        for resolver_ip, ok, data in r["results"]:
            res_parts.append(f"{resolver_ip}->{data if ok else 'X'}")
        lines.append(f"❌ {d} — {', '.join(res_parts)}")

    message = "<b>❌ پاسخی از DNSهای رایج دریافت نشد (8.8.8.8 / 8.8.4.4 / 1.1.1.1)</b>\n\n" + "\n".join(lines)
    print("\n--- Sending Telegram report ---")
    logging.info("Sending report (not resolved count=%d)", len(not_resolved))

    ok = send_telegram_message(message)
    if ok:
        print("✅ Telegram report sent.")
        logging.info("Telegram report sent.")
    else:
        print("[!] Failed to send Telegram report. See logs for details.")
        logging.error("Failed to send Telegram report.")

    logging.info("==== job finished ====")
    print("=== done ===")

if __name__ == "__main__":
    main()
