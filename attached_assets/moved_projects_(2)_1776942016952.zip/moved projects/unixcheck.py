#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import random
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from dotenv import load_dotenv
import logging
import html
import json

# ---------- تنظیمات ----------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
URLS_FILE = os.path.join(SCRIPT_DIR, "urls.txt")
ENV_FILE = os.path.join(SCRIPT_DIR, ".env")
LOG_FILE = os.path.join(SCRIPT_DIR, "unixcheck.log")

# -----------------------------
# Load ENV once (script-local .env)
# -----------------------------
load_dotenv(ENV_FILE)

# Accept both legacy and new variable names for compatibility
TELEGRAM_TOKEN = (
    os.getenv("TELEGRAM_TOKEN_PRODUCTS")
    or os.getenv("TOKEN")
)

_raw_chat_ids = (
    os.getenv("CHAT_ID_PRODUCTS")
    or os.getenv("CHAT_IDS")
    or ""
)
CHAT_IDS = [cid.strip() for cid in _raw_chat_ids.split(",") if cid.strip()]

MAX_TRIES = 3
HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
TIMEOUT = 10

# ---------- لاگینگ ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler()
    ]
)

# ---------- توابع کمکی دامنه ----------
def _normalize_host(url: str) -> str:
    host = urlparse(url).netloc.lower()
    if host.startswith("www."):
        host = host[4:]
    return host


def _is_same_domain(base_url: str, href: str) -> bool:
    return _normalize_host(base_url) == _normalize_host(href)


def _display_domain(url: str) -> str:
    """برای نمایش در گزارش (بدون https:// و www)."""
    host = urlparse(url).netloc or url
    host = host.lower()
    if host.startswith("www."):
        host = host[4:]
    return host


# ---------- تلگرام ----------
def _send_telegram_raw(text: str):
    if not TELEGRAM_TOKEN or not CHAT_IDS:
        logging.error(
            f"Telegram Token or Chat IDs missing. "
            f"TOKEN set? {bool(TELEGRAM_TOKEN)}  CHAT_IDS count={len(CHAT_IDS)}"
        )
        return

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    last_resp = None

    for chat_id in CHAT_IDS:
        data = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        resp = requests.post(url, data=data, timeout=15)
        logging.info(
            f"Telegram raw to {chat_id} status={resp.status_code} body={resp.text}"
        )
        resp.raise_for_status()
        last_resp = resp

    return last_resp


def send_telegram_message(message: str) -> None:
    # چک اولیه‌ی env
    if not TELEGRAM_TOKEN or not CHAT_IDS:
        logging.error(
            f"Telegram Token or Chat IDs missing. "
            f"TOKEN set? {bool(TELEGRAM_TOKEN)}  CHAT_IDS count={len(CHAT_IDS)}"
        )
        return

    # --- مرحله ۱: تلاش برای ارسال در یک پیام به همه ---
    try:
        _send_telegram_raw(message)
        return
    except requests.HTTPError as http_err:
        text = getattr(http_err.response, "text", "") or ""
        too_long = False
        try:
            j = json.loads(text)
            desc = (j.get("description") or "").lower()
            if "message is too long" in desc:
                too_long = True
        except Exception:
            pass

        if not too_long:
            logging.error(f"Telegram HTTP error (not length-related): {http_err}")
            return

        logging.warning("Telegram message too long, falling back to chunked sending...")

    except Exception as e:
        logging.error(f"Telegram send error (single message): {e}")
        return

    # --- مرحله ۲: اگر خیلی طولانی بود، تکه‌تکه بفرست (برای همه‌ی CHAT_IDS) ---
    max_len = 3800  # حاشیه امن زیر 4096
    lines = message.splitlines(True)
    chunks = []
    buf = ""

    for line in lines:
        if len(buf) + len(line) > max_len:
            chunks.append(buf)
            buf = ""
        buf += line
    if buf:
        chunks.append(buf)

    if not chunks:
        chunks = [message]

    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    for i, chunk in enumerate(chunks, start=1):
        for chat_id in CHAT_IDS:
            data = {
                "chat_id": chat_id,
                "text": chunk,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            }
            try:
                resp = requests.post(url, data=data, timeout=15)
                logging.info(
                    f"Telegram part {i}/{len(chunks)} to {chat_id} "
                    f"status={resp.status_code} body={resp.text}"
                )
                resp.raise_for_status()
            except Exception as e:
                logging.error(
                    f"Telegram send error part {i}/{len(chunks)} "
                    f"to {chat_id}: {e}"
                )


# ---------- گرفتن لینک محصول از خود صفحه ----------
def get_product_links_from_page(base_url: str):
    """لینک‌های محصول رو فقط از خود صفحه می‌گیرد."""
    try:
        r = requests.get(base_url, headers=HEADERS, timeout=TIMEOUT)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")
        links = []
        for a in soup.find_all("a", href=True):
            href = urljoin(base_url, a["href"])
            if not _is_same_domain(base_url, href):
                continue
            if any(x in href.lower() for x in ["product", "item", "category", "shop"]):
                links.append(href)
        return list(set(links))
    except Exception as e:
        logging.error(f"Error fetching {base_url}: {e}")
        return []


# ---------- گرفتن لینک محصول از product-sitemap.xml ----------
def get_product_links_from_sitemap(base_url: str):
    """اگر لازم شد، از product-sitemap.xml لینک محصول می‌گیرد."""
    links = []
    try:
        sitemap_url = urljoin(base_url, "product-sitemap.xml")
        logging.info(f"Trying sitemap for {base_url}: {sitemap_url}")
        sr = requests.get(sitemap_url, headers=HEADERS, timeout=TIMEOUT)
        if sr.status_code != 200:
            logging.warning(
                f"product-sitemap.xml not found for {base_url} (status {sr.status_code})"
            )
            return []
        sitemap_soup = BeautifulSoup(sr.text, "xml")
        for loc in sitemap_soup.find_all("loc"):
            href = (loc.get_text() or "").strip()
            if not href:
                continue
            href = urljoin(sitemap_url, href)
            if not _is_same_domain(base_url, href):
                continue
            if any(x in href.lower() for x in ["product", "item", "shop"]):
                links.append(href)
    except Exception as e:
        logging.error(f"Error fetching product-sitemap.xml for {base_url}: {e}")
    return list(set(links))


# ---------- تست کردن لینک‌های محصول ----------
def check_product_page(urls):
    """چند تا لینک رو رندوم تست می‌کند تا یکی 200/301/302 بده."""
    tries = 0
    last_tried = None
    urls_to_try = list(urls)
    while urls_to_try and tries < MAX_TRIES:
        link = random.choice(urls_to_try)
        last_tried = link
        try:
            r = requests.get(link, headers=HEADERS, timeout=TIMEOUT)
            if r.status_code in (200, 301, 302):
                return True, link
            else:
                urls_to_try.remove(link)
        except Exception:
            urls_to_try.remove(link)
        tries += 1
    return False, last_tried


# ---------- اجرای اصلی ----------
if not os.path.exists(URLS_FILE):
    msg = f"urls.txt not found at {URLS_FILE}"
    logging.critical(msg)
    send_telegram_message(f"<b>CRITICAL ERROR</b>\n{msg}")
    raise SystemExit(1)

if not TELEGRAM_TOKEN or not CHAT_IDS:
    logging.critical(
        "Telegram TOKEN or CHAT_ID_PRODUCTS (list) not loaded from .env"
    )
    raise SystemExit(1)

with open(URLS_FILE, "r", encoding="utf-8") as f:
    domains = [line.strip() for line in f if line.strip()]

if not domains:
    logging.warning("urls.txt is empty. Exiting.")
    send_telegram_message("⚠️ Product check ran, but <b>urls.txt</b> was empty.")
    raise SystemExit(0)

successful = []
failed = []

logging.info("=== unixcheck.py starting ===")
for domain in domains:
    logging.info(f"[·] Checking {domain} ...")

    ok = False
    last_link = None

    # مرحله ۱: تلاش از خود صفحه
    product_links = get_product_links_from_page(domain)
    if product_links:
        ok, last_link = check_product_page(product_links)

    # مرحله ۲: اگر از HTML چیزی درنیومد → برو سراغ product-sitemap.xml
    if not ok:
        logging.info(
            f"[!] No working product page from HTML for {domain}, "
            f"trying product-sitemap.xml ..."
        )
        sitemap_links = get_product_links_from_sitemap(domain)
        if sitemap_links:
            ok, last_link = check_product_page(sitemap_links)

    if ok:
        logging.info(f"[OK] {domain} -> {last_link}")
        successful.append((domain, last_link))
    else:
        logging.warning(f"[FAIL] {domain} (last: {last_link})")
        failed.append((domain, last_link))

# ---------- ساختن پیام و ارسال ----------
message = "<b>📊 گزارش بررسی صفحه محصولات یونیکسی</b>\n\n"

if successful:
    message += "🟢 <b>در دسترس:</b>\n"
    for d, link in successful:
        name = _display_domain(d)  # بدون https://
        if link:
            href_escaped = html.escape(link, quote=True)
            message += (
                f"✅ <code>{name}</code> → "
                f"<a href=\"{href_escaped}\">product</a>\n"
            )
        else:
            message += f"✅ <code>{name}</code>\n"

if failed:
    message += "\n🔴 <b>خارج از دسترس / مشکل‌دار:</b>\n"
    for d, link in failed:
        name = _display_domain(d)
        if link:
            href_escaped = html.escape(link, quote=True)
            message += (
                f"❌ <code>{name}</code> "
                f"(last: <a href=\"{href_escaped}\">link</a>)\n"
            )
        else:
            message += f"❌ <code>{name}</code> (هیچ صفحه‌ای باز نشد)\n"

send_telegram_message(message)
logging.info("=== Report sent to Telegram ===")
logging.info("=== done ===")
