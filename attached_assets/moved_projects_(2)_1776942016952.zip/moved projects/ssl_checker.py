import ssl
import socket
from datetime import datetime
import requests
import os
from dotenv import load_dotenv

# ----------------------------------------
# Load environment variables from .env file
# ----------------------------------------
load_dotenv("/home/.env")
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN_SSL")
CHAT_ID = os.getenv("CHAT_ID_SSL","")
SITES_FILE = "/home/sites.txt"

# ----------------------------------------
# Send message to Telegram
# ----------------------------------------
def send_telegram_message(message):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    data = {"chat_id": CHAT_ID, "text": message, "parse_mode": "HTML"}
    try:
        response = requests.post(url, data=data, timeout=10)
        response.raise_for_status()
    except Exception as e:
        print(f"[!] Telegram send error: {e}")

# ----------------------------------------
# Get SSL certificate expiry date
# ----------------------------------------
def get_ssl_expiry_date(hostname):
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=5) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            expiry_date = datetime.strptime(cert['notAfter'], '%b %d %H:%M:%S %Y %Z')
            return expiry_date

# ----------------------------------------
# Read sites list
# ----------------------------------------
if not os.path.exists(SITES_FILE):
    print(f"[!] File not found: {SITES_FILE}")
    exit()

with open(SITES_FILE, "r") as f:
    sites = [line.strip() for line in f if line.strip()]

successful_sites = []
warning_sites = []
error_sites = []

# ----------------------------------------
# Check each site's SSL
# ----------------------------------------
for site in sites:
    hostname = site.replace("https://", "").replace("http://", "").split('/')[0]

    try:
        expiry = get_ssl_expiry_date(hostname)
        days_left = (expiry - datetime.utcnow()).days

        if days_left <= 20:
            warning_sites.append(f"⚠️ {hostname}: only {days_left} days left")
        else:
            successful_sites.append(f"✅ {hostname}: {days_left} days remaining")

        print(f"[✓] {hostname} checked successfully.")

    except Exception as e:
        error_sites.append(f"❌ {hostname}: error or no response")
        print(f"[x] {hostname} -> error: {e}")

# ----------------------------------------
# Format and send Telegram report
# ----------------------------------------
def format_section(title, emoji, items):
    formatted = f"<b>{emoji} {title}</b>\n\n"
    formatted += "\n\n".join([f"<code>{item}</code>" for item in items])
    formatted += "\n\n" + "─" * 20 + "\n"
    return formatted

final_message = ""

if successful_sites:
    final_message += format_section("Valid SSL Certificates UNIXSEE", "📊", successful_sites)

if warning_sites:
    final_message += format_section("Expiring Soon (less than 20 days)", "🚨", warning_sites)

if error_sites:
    final_message += format_section("Errors or Unreachable Sites", "🚫", error_sites)

if final_message:
    send_telegram_message(final_message)
else:
    print("No sites to check.")

