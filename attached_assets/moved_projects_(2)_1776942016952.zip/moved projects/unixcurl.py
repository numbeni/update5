#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import requests
from dotenv import load_dotenv

# -------------------------------
# Load environment variables from /home/.env
# -------------------------------
env_path = "/home/.env"
if not os.path.exists(env_path):
    raise Exception(f"❌ فایل env پیدا نشد: {env_path}")

load_dotenv(env_path)

TOKEN = os.getenv("TELEGRAM_TOKEN_CURL")
CHAT_IDS_RAW = os.getenv("CHAT_IDS_CURL", "")

if not TOKEN:
    raise Exception("❌ متغیر TELEGRAM_TOKEN_CURL در فایل env پیدا نشد")

CHAT_IDS = [x.strip() for x in CHAT_IDS_RAW.split(",") if x.strip()]
if not CHAT_IDS:
    raise Exception("❌ متغیر CHAT_IDS_CURL در فایل env پیدا نشد یا خالی است")

# -------------------------------
# Domains file
# -------------------------------
DOMAINS_FILE = "/home/domains.txt"
if not os.path.exists(DOMAINS_FILE):
    raise Exception(f"❌ فایل domains.txt پیدا نشد: {DOMAINS_FILE}")

with open(DOMAINS_FILE, "r") as f:
    DOMAINS = [line.strip() for line in f if line.strip()]

# -------------------------------
# HTTP status codes meaning
# -------------------------------
HTTP_CODES = {
    "100": "Continue", "101": "Switching", "200": "OK", "201": "Created",
    "202": "Accepted", "204": "No Content", "301": "Moved", "302": "Found",
    "303": "See Other", "307": "Temp Redirect", "308": "Perm Redirect",
    "400": "Bad Request", "401": "Unauthorized", "403": "Forbidden",
    "404": "Not Found", "405": "Method Not Allowed", "408": "Timeout",
    "500": "Server Error", "501": "Not Implemented", "502": "Bad Gateway",
    "503": "Service Unavailable", "504": "Gateway Timeout"
}

# -------------------------------
# Functions
# -------------------------------
def run_curl(domain):
    try:
        result = subprocess.run(
            ["curl", "-I", "-s", "-o", "/dev/null", "-w", "%{http_code}", domain],
            capture_output=True, text=True, timeout=15
        )
        code = result.stdout.strip()
        meaning = HTTP_CODES.get(code, "Unknown")
        return code, meaning
    except Exception as e:
        return "ERR", str(e)

def color_code(code):
    if code.startswith("2"):
        return "🟢"
    elif code.startswith("3"):
        return "🟡"
    elif code.startswith("4") or code.startswith("5"):
        return "🔴"
    else:
        return "⚪"

def send_telegram(message):
    for chat_id in CHAT_IDS:
        try:
            requests.post(
                f"https://api.telegram.org/bot{TOKEN}/sendMessage",
                data={"chat_id": chat_id, "text": message, "parse_mode": "Markdown"}
            )
        except Exception as e:
            print(f"Telegram error for {chat_id}: {e}")

# -------------------------------
# Main
# -------------------------------
def main():
    normal_report = "*🔎 گزارش یونیکسی CURL*\n\n"
    error_report = "*⚠️ سایت‌های مشکل‌دار ⚠️*\n\n"

    for domain in DOMAINS:
        code, meaning = run_curl(domain)
        emoji = color_code(code)
        line = f"🌐 `{domain}` → {emoji} {code} {meaning}\n"

        if emoji == "⚪":
            error_report += line
        else:
            normal_report += line

    # اضافه کردن راهنمای رنگ‌ها فقط در بخش اصلی
    normal_report += "\n🔹 توضیح رنگ‌ها:\n"
    normal_report += "🟢 موفق (2xx) | 🟡 ریدایرکت (3xx) | 🔴 خطا (4xx/5xx) | ⚪ نامعلوم/خطا\n"

    # پایان گزارش
    normal_report += "\n✅ پایان گزارش"

    # ترکیب دو بخش در یک پیام
    final_report = normal_report
    if error_report.strip() != "*⚠️ سایت‌های مشکل‌دار ⚠️*":
        final_report += "\n\n" + error_report

    send_telegram(final_report)

if __name__ == "__main__":
    main()
